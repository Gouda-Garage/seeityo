# BIG — Tiny print. One tap.

Android prototype. Every push to `main` builds `BIG.apk` and publishes it under **Releases**.

## Install on Android
1. On your phone, open the latest Release and download `BIG.apk`.
2. Tap the download. If asked, allow installs from Chrome/Files.
3. Open BIG, allow camera. Done.

## iPhone testers
Use the web version: https://bigread.pages.dev/app → Share → Add to Home Screen.

Nothing is saved, no account, no tracking.
